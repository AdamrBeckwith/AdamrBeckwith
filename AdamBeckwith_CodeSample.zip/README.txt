Hello! 

I am Adam Beckwith, and this file contains two samples of my code. 

The first is a coding sample where I inplement Caches in C. 

The second is a coding sample of a notetaking website. 

Please feel free to look at either or both, depending on what you think will be most informative.
 I will warn that the Cache sample is about 6 months older, but should still be useful. 

Thank you for checking out my code :) 