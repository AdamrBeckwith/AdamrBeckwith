Hello! 


I am Adam Beckwith and this code sample is work from a project in my Computer Systems course. 
All work in these classes are pair-programming, so I must thank my partner Chris Couto for assistance. 
Although it is pair work, I promise that we both contributed equally to the project both conceptually and 
actually typing the code.

This code shows our work with caches! In csim.c is our personal implementation of a cache. 
In trans.c we transpose a matrix as efficiently as possible in various forms.  This code work is in C,
but I am also proficient in Python, java and C++. 

I hope this code sample shows my proficiency as a coder, and my understanding of key computer science 
elements. 

Thank you for looking at my code! Please have a wonderful day. 
